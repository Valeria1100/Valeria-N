/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;
int main()
{
	int num1, resultado;
	cout<<"Digite un numero";
	cin>>num1;
	resultado=num1*3;
	cout<<"el resultado es "<<resultado<<endl;
    resultado=num1*4;
    cout<<"el resultado es "<<resultado<<endl;
    resultado=num1*5;
    cout<<"el resultado es "<<resultado<<endl;
    resultado=num1*6;
    cout<<"el resultado es "<<resultado<<endl;
     resultado=num1*7;
    cout<<"el resultado es "<<resultado<<endl;
}